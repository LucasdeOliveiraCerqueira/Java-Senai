import java.util.ArrayList;

public class List_Products {
    public List_Products(ArrayList<Product> productArrayList) {
        if (!productArrayList.isEmpty()) {
            for (Product product : productArrayList) {
                System.out.println(product);
            }
        } else System.out.println("There are no products listed!");
    }
}