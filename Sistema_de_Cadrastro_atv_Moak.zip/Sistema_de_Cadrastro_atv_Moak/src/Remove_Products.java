import java.util.ArrayList;
import java.util.Scanner;

public class Remove_Products {
    public Remove_Products(ArrayList<Product> productArrayList) {
        Scanner sc = new Scanner(System.in);


        if (!productArrayList.isEmpty()) {
            System.out.println("What is the product ID? ");
            int Id_insert = sc.nextInt();

            for (int i = 0; i < productArrayList.size() ; i++) {
                if (productArrayList.get(i).getId() == Id_insert) {
                    productArrayList.remove(i);
                    System.out.println("Removed!");
                    break;
                }
            }
        } else System.out.println("There are no products listed!");
    }
}
