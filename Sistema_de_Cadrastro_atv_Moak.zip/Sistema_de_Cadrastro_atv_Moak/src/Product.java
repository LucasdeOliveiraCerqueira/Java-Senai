import java.util.Scanner;

public class Product {
    private int Id;
    private String Name;
    private float Price;
    private int Amount;


    public  Product(int Id,int amount, String Name, float Price){
        this.Id = Id;
        this.Amount = amount;
        this.Name = Name;
        this.Price = Price;
    }


    public int getId() {
        return Id;
    }


    public void setId(int id) {
        Id = id;
    }


    public String getName() {
        return Name;
    }


    public void setName(String name) {
        Name = name;
    }


    public float getPrice() {
        return Price;
    }


    public void setPrice(float price) {
        Price = price;
    }


    public int getAmount() {
        return Amount;
    }


    public void setAmount(int amount) {
        this.Amount = amount;
    }

    public Product() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Insert Id: ");
        Id = sc.nextInt();
        System.out.println("Insert Amount: ");
        Amount = sc.nextInt();
        System.out.println("Insert Name: ");
        sc.nextLine();
        Name = String.valueOf(sc.nextLine());
        System.out.println("Insert Price: ");
        Price = sc.nextFloat();

        return;
    }
    public String toString(){
        return ("Id: ") + Id + ("\nName: ") + Name + ("\nAmount: ") + Amount + ("\nPrice: R$ ") + Price;
    }
}