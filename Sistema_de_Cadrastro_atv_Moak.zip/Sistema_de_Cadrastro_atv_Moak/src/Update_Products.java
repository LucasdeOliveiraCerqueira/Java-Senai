import java.util.ArrayList;
import java.util.Scanner;

public class Update_Products {
    public Update_Products(ArrayList<Product> productArrayList) {

        System.out.println();

        Scanner sc = new Scanner(System.in);
        Scanner ssc = new Scanner(System.in);

        System.out.println("What is the product ID? ");
        int Id_insert = sc.nextInt();

        if (!productArrayList.isEmpty()) {
            for (int i = 0; i < productArrayList.size() ; i++) {
                if (productArrayList.get(i).getId() == Id_insert) {
                    System.out.println("What is new name the product ID? ");
                    sc.nextLine();
                    String NewName = sc.nextLine();
                    productArrayList.get(i).setName(NewName);

                    System.out.println("What is new price the product ID? ");
                    float NewPrice = sc.nextFloat();
                    productArrayList.get(i).setPrice(NewPrice);

                    System.out.println("What is new Amount the product ID? ");
                    int NewAmount = sc.nextInt();
                    productArrayList.get(i).setAmount(NewAmount);
                    System.out.println("Updated!");
                    break;
                } else System.out.println("There are no products with that ID to update!");
            }
        } else System.out.println("There are no products listed!");
    }
}