import java.util.ArrayList;

public class Product_Registration {
    Product_Registration(ArrayList<Product> productArrayList) {
        Main.ProductArrayList.add(new Product());
    }
}