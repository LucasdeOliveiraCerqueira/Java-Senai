import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static ArrayList<Product> ProductArrayList =  new ArrayList<>();

    static int Insert;

    public static int getInsert() {
        return Insert;
    }

    public static void setInsert(int insert) {
        Insert = insert;
    }

    public static void main(String[] args) {
        do {
            System.out.println("\n#### SYSTEM PRODUCT ####");
            System.out.println("1 - PRODUCT REGISTRATION");
            System.out.println("2 - LIST PRODUCTS");
            System.out.println("3 - UPDATE PRODUCTS");
            System.out.println("4 - REMOVE PRODUCTS");
            System.out.println("5 - EXIT");
            System.out.println("\nChoose an option: ");

            Scanner sc = new Scanner(System.in);
            int Insert = sc.nextInt();
            sc.nextLine();

            System.out.println("\n");

            switch (Insert){
                case 1:
                    new Product_Registration(ProductArrayList);
                    break;
                case 2:
                    new List_Products(ProductArrayList);
                    break;
                case 3:
                    new Update_Products(ProductArrayList);
                    break;
                case 4:
                    new Remove_Products(ProductArrayList);
                    break;
                case 5:
                    System.out.println("Turning Off...");
                    return;
            }
        } while (Insert != 5);
    }
}